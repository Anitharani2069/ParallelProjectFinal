package com.capg.service;

import com.capg.bank.bean.CustomerDetails;

public interface CustomerServiceIntf {
	
	public void createAccount(CustomerDetails service);
	public CustomerDetails showBalance(long accno);
	public CustomerDetails deposit(long accno, int amount,String trans);
	public CustomerDetails withdraw(long accno, int amount,String trans);
	public CustomerDetails fundTransfer(long sourceAccNo, long destAccNo, int transfamount,String sourcetrans,String desttrans);
	public String printTransactions(long accno);
	
}
