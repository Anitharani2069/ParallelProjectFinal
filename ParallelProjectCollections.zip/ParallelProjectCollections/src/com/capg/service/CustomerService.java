package com.capg.service;

import java.util.regex.Pattern;

import com.capg.bank.bean.CustomerDetails;
import com.capg.bank.dao.CustomerDao;
import com.capg.bank.exception.BankException;

public class CustomerService implements CustomerServiceIntf{
	
	CustomerDao dao = new CustomerDao();
	
	
	@Override
	public void createAccount(CustomerDetails service) {
		// TODO Auto-generated method stub
		dao.createAccount(service);
	}

	@Override
	public CustomerDetails showBalance(long accno) {
		// TODO Auto-generated method stub
		return dao.showBalance(accno);
	}

	@Override
	public CustomerDetails deposit(long accno, int amount, String trans) {
		// TODO Auto-generated method stub
		String transaction = trans + "\n" + dao.getHashMap().get(accno).getTransaction();
		CustomerDetails depositObj = dao.deposit(accno, transaction);
		float initialBalance = depositObj.getBalance();
		float finalBalance = initialBalance + amount;
		depositObj.setBalance(finalBalance);

		return depositObj;
	}

	@Override
	public CustomerDetails withdraw(long accno, int amount, String trans) {
		// TODO Auto-generated method stub
		String transaction = trans + "\n" + dao.getHashMap().get(accno).getTransaction();
		CustomerDetails withDrawObj = dao.withdraw(accno, transaction);
		float initialBalance = withDrawObj.getBalance();
		float finalBalance = initialBalance - amount;
		withDrawObj.setBalance(finalBalance);
		return withDrawObj;
	}

	@Override
	public CustomerDetails fundTransfer(long sourceAccNo, long destAccNo, int transfamount, String sourcetrans,
			String desttrans) {
		// TODO Auto-generated method stub
		String transaction = sourcetrans + "\n" + dao.getHashMap().get(sourceAccNo).getTransaction();

		//
		CustomerDetails fundTransSource = dao.SourcefundTransfer(sourceAccNo, transaction);
		
		String destTransaction = desttrans + "\n" + dao.getHashMap().get(destAccNo).getTransaction();
		
		CustomerDetails fundTransDest = dao.DestinationfundTransfer(destAccNo, destTransaction);
		
		
		float SourceinitialBalance = fundTransSource.getBalance();
		float DestinationinitialBalance = fundTransDest.getBalance();
		float sourceFinalBal = SourceinitialBalance - transfamount;
		float destinationFinalBal = DestinationinitialBalance + transfamount;
		
		fundTransSource.setBalance(sourceFinalBal);
		fundTransDest.setBalance(destinationFinalBal);
		
		return fundTransSource;
		}

		
		@Override
		public String printTransactions(long accno) {
		// TODO Auto-generated method stub
			return dao.printTransaction(accno);
		}
	

	public boolean isNameValid(String customerName) {
		
		if(customerName.length()<3) {
			System.out.println("Customer name must be greater than 3 characters");
		}
		else
		
			if(Pattern.matches("[A-Z]([a-z])*", customerName)){
		        return true;
		}
			else {
	        	  try {
	              	throw new BankException("Name Should Start with capital Letter and continue with small letters");
	              }catch(BankException exception) {
	              	System.out.println(exception.getMessage());
	              	//return false;
	              }
	
			}
		return false;
		}
	
		
	
	
	
			public boolean isPhoneNoValid(String phoneNo) {
				if (phoneNo.matches("^[6-9][0-9]{9}$")) {
					return true;
				} else {
					try {
						throw new BankException("PhoneNumber is not Valid");
					} catch (BankException exception) {
						System.out.println(exception);
						return false;
					}
				}

			}
			
			public boolean isEmailValid(String email)
			{
				if (email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
					return true;
				} else {
					try {
						throw new BankException("Email is not Valid");
					} catch (BankException exception) {
						System.out.println(exception);
						return false;
					}
				}

			}
			
			
			
			
			public boolean isAccountValid(long accountNo){
				if (dao.getHashMap().containsKey(accountNo)) {
					return true;
				} else {
					try {
						throw new BankException("No such Account Found");
					} catch (BankException exception) {
						System.out.println(exception);
						return false;
					}
					
				}
			}

	
}
