package com.capg.bank.dao;

import java.util.HashMap;

import com.capg.bank.bean.CustomerDetails;

public class CustomerDao implements CustomerDaoIntf{
	
	HashMap<Long, CustomerDetails> hashmap = new HashMap<Long, CustomerDetails>();

	
	public HashMap<Long, CustomerDetails> getHashMap() {
		return hashmap;
	}
	
	
	@Override
	public void createAccount(CustomerDetails customer) {
		// TODO Auto-generated method stub
		hashmap.put(customer.getAccountNo(),customer);
	}

	@Override
	public CustomerDetails showBalance(long accno) {
		// TODO Auto-generated method stub
		return hashmap.get(accno);
	}

	@Override
	public CustomerDetails deposit(long accno, String trans) {
		hashmap.get(accno).setTransaction(trans);
		CustomerDetails depositObj = hashmap.get(accno);
		return depositObj;

	}

	@Override
	public CustomerDetails withdraw(long accno, String trans) {
		hashmap.get(accno).setTransaction(trans);
		CustomerDetails withdrawObj = hashmap.get(accno);
		return withdrawObj;
	}

	@Override
	public CustomerDetails SourcefundTransfer(long sourceAccNo, String trans) {
		// TODO Auto-generated method stub
		hashmap.get(sourceAccNo).setTransaction(trans);
		CustomerDetails sourceObj = hashmap.get(sourceAccNo);
		return sourceObj;
	}

	@Override
	public CustomerDetails DestinationfundTransfer(long destAccNo, String trans) {
		hashmap.get(destAccNo).setTransaction(trans);
		CustomerDetails DestObj = hashmap.get(destAccNo);
		return DestObj;
	}

	@Override
	public String printTransaction(long accno) {
		// TODO Auto-generated method stub
		return hashmap.get(accno).getTransaction();
	}

}
