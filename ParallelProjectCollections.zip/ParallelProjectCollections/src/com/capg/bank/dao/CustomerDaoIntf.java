package com.capg.bank.dao;

import com.capg.bank.bean.CustomerDetails;

public interface CustomerDaoIntf {
	
	public void createAccount(CustomerDetails customer);
	public CustomerDetails showBalance(long accno);
	public CustomerDetails deposit(long accno,String trans);
	public CustomerDetails withdraw(long accno,String trans);
	public CustomerDetails SourcefundTransfer(long sourceAccNo,String trans);
	public CustomerDetails DestinationfundTransfer(long destinationAccNo,String trans);
	public String printTransaction(long accno);
	
}
