package com.capg.bank.exception;

public class BankException extends Exception {
	 public BankException(String message){
	     System.err.println(message);
	    }

}
