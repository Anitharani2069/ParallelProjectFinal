package com.capg.bank.bean;

public class CustomerDetails {
	
	private String customerName;
	private String phoneNo;
	private long accountNo;
	private String email;
	private float balance;
	private String transaction;
	
	
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	public String getTransaction() {
		return transaction;
	}
	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}
	
	
	public CustomerDetails() {
		super();
	}
	
	
	
	
	
	public CustomerDetails(String customerName, String phoneNo, long accountNo, float balance, String email,
			String transaction) {
		super();
		this.customerName = customerName;
		this.phoneNo = phoneNo;
		this.accountNo = accountNo;
		this.email = email;
		this.balance = balance;
		this.transaction = transaction;
	}
	@Override
	public String toString() {
		return "CustomerDetails [customerName=" + customerName + ", phoneNo=" + phoneNo + ", accountNo=" + accountNo
				+ ", email=" + email + ", balance=" + balance + ", transaction=" + transaction + "]";
	}
	
	
}
