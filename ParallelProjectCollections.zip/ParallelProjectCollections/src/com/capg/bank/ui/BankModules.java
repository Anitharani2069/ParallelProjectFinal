package com.capg.bank.ui;
import java.util.Random;
import java.util.Scanner;

import com.capg.bank.bean.CustomerDetails;
import com.capg.service.CustomerService;


public class BankModules {
	Random random = new Random();
	CustomerService serviceObj = new CustomerService();
	Scanner scan = new Scanner(System.in);

	public void createAccount() {
		
		System.out.println("Enter the customer Details");
		
		String customerName;
		do {
			System.out.println("Enter Your Full Name:");
			customerName = scan.next();
		} 
		while (!serviceObj.isNameValid(customerName));
		
		
		String phoneNo;
		do {
			System.out.println("Enter Your Mobile Number:");
			phoneNo = scan.next();
		} while (!serviceObj.isPhoneNoValid(phoneNo));
		
		
		String email;
		do {

			System.out.println("Enter Your Email Id:");
			email = scan.next();
		} while (!serviceObj.isEmailValid(email));
		
		
		
		long accNo = random.nextInt(1000000000);
		float balance = 500;
		System.out.println("Your Initial Balance: " + balance);
		System.out.println("Your Account Number : " + accNo);
		System.out.println("Your Account is created Successfully!!");
		String transaction = "Account was created with Initial Balance:" + balance;
		CustomerDetails customer = new CustomerDetails(customerName, phoneNo, accNo, balance, email, transaction);
		serviceObj.createAccount(customer);

	}

	public void showBalance()  {
		long accNo;
		do {
			System.out.println("Enter Your Account Number:");
			accNo = scan.nextLong();
		}
		while (!serviceObj.isAccountValid(accNo));
		CustomerDetails showBalObj = serviceObj.showBalance(accNo);
		System.out.println("Your Balance is:" + showBalObj.getBalance());

	}

	public void deposit() {
		long accNo;
		do {
			System.out.println("Enter Your Account Number:");
			accNo = scan.nextLong();
		} while (!serviceObj.isAccountValid(accNo));
		System.out.println("Enter the Amount to deposit:");
		int amount = scan.nextInt();
		String transaction = "deposited :" + amount;
		CustomerDetails depositObj = serviceObj.deposit(accNo, amount, transaction);
		System.out.println("Your current balance is" + depositObj.getBalance());

	}

	
	public void withdraw() {
		long accno;
		do {
			System.out.println("Enter Your Account Number:");
			accno = scan.nextLong();
		} while (!serviceObj.isAccountValid(accno));
		System.out.println("Enter the Amount to WothDraw:");
		int amount = scan.nextInt();
		String transaction = "withdrawed:" + amount;
		CustomerDetails customer = serviceObj.withdraw(accno, amount, transaction);
		System.out.println("your current balance is" + customer.getBalance());

	}

	public void fundTransfer(){
		long sourceAccNo;
		do {
			System.out.println("Enter your AccountNumber:");
			sourceAccNo = scan.nextLong();
		} while (!serviceObj.isAccountValid(sourceAccNo));
		
		long destinationAccNo;
		do {
			System.out.println("enter the AccountNumber to be transfered:");
			destinationAccNo = scan.nextLong();
		} while (!serviceObj.isAccountValid(destinationAccNo));
		
		System.out.println("Enter the Amount to be transfered:");
		int transfamount = scan.nextInt();
		String Sourcetransaction = "Amount Transfered to:" + sourceAccNo + "amount:" + transfamount;
		String Destitransaction = "Amount Received From:" + destinationAccNo + "amount:" + transfamount;
		CustomerDetails source = serviceObj.fundTransfer(sourceAccNo, destinationAccNo, transfamount, Sourcetransaction,
				Destitransaction);
		System.out.println("Transfered successfully!!" + "\n" + "Source Balance :" + source.getBalance());

	}

	public void printTransactions()  {
		long accno;
		do {
			System.out.println("Enter Your Account Number:");
			accno = scan.nextLong();
		} while (!serviceObj.isAccountValid(accno));
		System.out.println(serviceObj.printTransactions(accno));

	}
}
