package com.capg.bank.ui;

import java.util.Scanner;

public class MainUI {
	public static void main(String args[]){
		int number;
		char choice;
		BankModules user = new BankModules();
		Scanner scanner = new Scanner(System.in);
		
		do {
			
			System.out.println("*****************************WELCOME TO XYZ BANK************************************WELCOME TO XYZ BANK**************************************WELCOME TO XYZ BANK************************************");
			System.out.println("***************************************************************************************************************************************************************************************************************");
			System.out.println("\n1.Create New Acount");
			System.out.println("2.Show Balance");
			System.out.println("3.Deposit");
			System.out.println("4.WithDraw");
			System.out.println("5.Fund Transfer");
			System.out.println("6.Print Transactions");
			System.out.println("7.Exit");
			
			System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
			System.out.print("\nEnter your choice : ");
			
			number = scanner.nextInt();
			switch(number) {
			case 1:
				user.createAccount();
				break;
			case 2:
				user.showBalance();
				break;
			case 3:
				user.deposit();
				break;
			case 4:
				user.withdraw();
				break;
			case 5:
				user.fundTransfer();
				break;
			case 6:
				user.printTransactions();
				break;
			case 7:
				System.exit(0);
			}
			System.out.print("Do you want to continue (y/n)...? : ");
			choice = scanner.next().charAt(0);
			if(choice == 'y' || choice=='Y')
				continue;
			else {
				System.out.println("Thank You !");
				System.exit(0);
			}
		} while(choice != 7 );
		scanner.close();
	}

}
